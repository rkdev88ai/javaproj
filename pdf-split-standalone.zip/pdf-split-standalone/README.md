# Document Splitter — standalone edition

A single self-contained Java program: no Spring Boot, no Node/npm, no
separate frontend build step. It uses only the JDK's built-in HTTP server
(`com.sun.net.httpserver`) plus Apache PDFBox 3.0.8 and a tiny JSON library.
The web UI (plain HTML/CSS/JS) is bundled directly inside the jar and served
by the same process that handles the API calls.

Run it, and it opens your default browser to the app automatically. Same
splitting behavior and same choice between the `Splitter` and `Import page`
PDFBox strategies as the Spring Boot + React version — just packaged as one
executable instead of two separate processes.

## Build

Requires JDK 17+ and Maven (only needed to *build* the jar — not to run it).

```
cd pdf-split-standalone
mvn package
```

This produces `target/pdf-split-standalone.jar` — a single fat jar with
PDFBox, the JSON library, and the web UI all bundled inside it.

## Run

```
java -jar target/pdf-split-standalone.jar
```

- Opens `http://localhost:8080` in your default browser automatically.
- Uploaded files (and split output files) are stored under `./uploads`,
  relative to wherever you run the command from.
- To use a different upload/output folder, pass it as an argument:
  ```
  java -jar target/pdf-split-standalone.jar C:\pdf-splitter-files
  ```
- Stop it with Ctrl+C in the terminal window.

No `npm install`, no `npm start`, no separate backend/frontend terminals —
just the one command.

## What changed vs. the Spring Boot + React version

| | Spring Boot + React | Standalone |
|---|---|---|
| HTTP server | Spring Boot (embedded Tomcat) | JDK's `com.sun.net.httpserver` |
| Multipart file upload parsing | Spring's `MultipartFile` | Hand-written `MultipartParser.java` |
| JSON handling | Jackson (via Spring) | `org.json` (one small dependency) |
| Frontend | React, built separately with `npm` | Plain HTML/CSS/JS, bundled into the jar, no build step |
| Processes to run | 2 (backend + `npm start`) | 1 (`java -jar ...`) |
| Runtime dependencies | JDK, Maven-built Spring app | JDK only |

The core PDF-splitting logic in `PdfSplitService.java` — both the `Splitter`
strategy and the `importPage` strategy, the same validation rules, the same
output naming convention (`<original-name>_<fromPage>_<toPage>.pdf` written
next to the source file) — is otherwise unchanged from the Spring Boot
version, just without the `@Service`/`@Value` annotations.

## Endpoints (same contract as before)

- `POST /api/pdf/upload` — multipart form field `file`. Returns
  `{ originalFileName, filePath, totalPages }`.
- `POST /api/pdf/split` — JSON body `{ filePath, method, ranges }` where
  `method` is `"SPLITTER"` or `"IMPORT_PAGE"` and `ranges` is an array of up
  to 5 `{ fromPage, toPage }` objects. Returns an array of per-range results.

## Limitations of this version worth knowing

- The multipart parser (`MultipartParser.java`) handles exactly what a
  browser file-upload `<input>` sends — it is not a general-purpose MIME
  parser, so don't reuse it for arbitrary multipart traffic.
- No HTTPS, no authentication, no CORS handling — this is meant for local,
  single-user testing on one laptop, not for exposing over a network. For a
  shared/production deployment, the Spring Boot version (or adding TLS +
  auth here) is the more appropriate starting point.
- `HttpServer` is fine for local/demo load but isn't intended as a
  production-grade servlet container the way embedded Tomcat is.
