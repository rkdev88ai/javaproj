package com.example.pdfsplit.standalone;

import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * Minimal multipart/form-data parser. Spring's MultipartFile handled this for
 * free before; without a framework, browsers still send the same wire format,
 * so this reads it directly. Handles exactly what a file-upload <input> sends
 * (one or more parts, each with a Content-Disposition header) — it is not a
 * general-purpose MIME parser.
 */
public class MultipartParser {

    public static class Part {
        public String name;
        public String filename; // null for non-file fields
        public byte[] data;
    }

    public static List<Part> parse(byte[] body, String boundary) {
        List<Part> parts = new ArrayList<>();
        byte[] delimiter = ("--" + boundary).getBytes(StandardCharsets.ISO_8859_1);

        List<Integer> positions = new ArrayList<>();
        int searchFrom = 0;
        while (true) {
            int pos = indexOf(body, delimiter, searchFrom);
            if (pos == -1) break;
            positions.add(pos);
            searchFrom = pos + delimiter.length;
        }

        for (int i = 0; i < positions.size() - 1; i++) {
            int start = positions.get(i) + delimiter.length;
            int end = positions.get(i + 1);
            if (start >= end) continue;
            byte[] chunk = java.util.Arrays.copyOfRange(body, start, end);
            Part part = parsePart(chunk);
            if (part != null) {
                parts.add(part);
            }
        }
        return parts;
    }

    private static Part parsePart(byte[] chunk) {
        byte[] headerBodySeparator = "\r\n\r\n".getBytes(StandardCharsets.ISO_8859_1);
        int sepPos = indexOf(chunk, headerBodySeparator, 0);
        if (sepPos == -1) return null;

        String headerText = new String(chunk, 0, sepPos, StandardCharsets.ISO_8859_1).trim();

        int dataStart = sepPos + headerBodySeparator.length;
        int dataEnd = chunk.length;
        // Each part's data is followed by "\r\n" right before the next boundary marker.
        if (dataEnd >= 2 && chunk[dataEnd - 2] == '\r' && chunk[dataEnd - 1] == '\n') {
            dataEnd -= 2;
        }
        byte[] data = java.util.Arrays.copyOfRange(chunk, dataStart, Math.max(dataStart, dataEnd));

        String name = null;
        String filename = null;
        for (String line : headerText.split("\r\n")) {
            if (line.toLowerCase(Locale.ROOT).startsWith("content-disposition")) {
                name = extractAttribute(line, "name");
                filename = extractAttribute(line, "filename");
            }
        }
        if (name == null) return null;

        Part part = new Part();
        part.name = name;
        part.filename = (filename != null && !filename.isEmpty()) ? filename : null;
        part.data = data;
        return part;
    }

    private static String extractAttribute(String header, String attribute) {
        String marker = attribute + "=\"";
        int i = header.indexOf(marker);
        if (i == -1) return null;
        int start = i + marker.length();
        int end = header.indexOf('"', start);
        if (end == -1) return null;
        return header.substring(start, end);
    }

    private static int indexOf(byte[] array, byte[] target, int fromIndex) {
        int limit = array.length - target.length;
        outer:
        for (int i = Math.max(fromIndex, 0); i <= limit; i++) {
            for (int j = 0; j < target.length; j++) {
                if (array[i + j] != target[j]) {
                    continue outer;
                }
            }
            return i;
        }
        return -1;
    }
}
