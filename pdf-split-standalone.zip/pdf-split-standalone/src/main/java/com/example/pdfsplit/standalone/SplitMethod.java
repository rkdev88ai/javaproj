package com.example.pdfsplit.standalone;

/**
 * Which PDFBox strategy to use for producing each split file.
 *
 * SPLITTER    - org.apache.pdfbox.multipdf.Splitter (setStartPage/setEndPage/setSplitAtPage).
 * IMPORT_PAGE - Builds a new PDDocument and calls PDDocument.importPage() for each page
 *               in the range. Avoids Splitter's structure-tree/clone logic.
 */
public enum SplitMethod {
    SPLITTER,
    IMPORT_PAGE
}
