package com.example.pdfsplit.standalone;

import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpHandler;
import org.json.JSONObject;

import java.io.IOException;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.util.List;

public class UploadHandler implements HttpHandler {

    private final PdfSplitService service;

    public UploadHandler(PdfSplitService service) {
        this.service = service;
    }

    @Override
    public void handle(HttpExchange exchange) throws IOException {
        if (!"POST".equalsIgnoreCase(exchange.getRequestMethod())) {
            sendError(exchange, 405, "Method not allowed");
            return;
        }
        try {
            String contentType = exchange.getRequestHeaders().getFirst("Content-Type");
            if (contentType == null || !contentType.toLowerCase().startsWith("multipart/form-data")) {
                sendError(exchange, 400, "Expected multipart/form-data");
                return;
            }
            String boundary = extractBoundary(contentType);
            if (boundary == null) {
                sendError(exchange, 400, "Missing multipart boundary");
                return;
            }

            byte[] body = exchange.getRequestBody().readAllBytes();
            List<MultipartParser.Part> parts = MultipartParser.parse(body, boundary);

            MultipartParser.Part filePart = parts.stream()
                    .filter(p -> "file".equals(p.name) && p.filename != null)
                    .findFirst()
                    .orElse(null);

            if (filePart == null) {
                sendError(exchange, 400, "No file was uploaded.");
                return;
            }

            PdfSplitService.StoredFile stored = service.storeAndInspect(filePart.filename, filePart.data);

            JSONObject json = new JSONObject();
            json.put("originalFileName", stored.getOriginalFileName());
            json.put("filePath", stored.getFilePath());
            json.put("totalPages", stored.getTotalPages());

            sendJson(exchange, 200, json.toString());

        } catch (PdfProcessingException e) {
            sendError(exchange, 400, e.getMessage());
        } catch (Exception e) {
            sendError(exchange, 500, "Unexpected server error: " + e.getMessage());
        }
    }

    private String extractBoundary(String contentType) {
        for (String segment : contentType.split(";")) {
            segment = segment.trim();
            if (segment.startsWith("boundary=")) {
                String b = segment.substring("boundary=".length());
                if (b.startsWith("\"") && b.endsWith("\"") && b.length() >= 2) {
                    b = b.substring(1, b.length() - 1);
                }
                return b;
            }
        }
        return null;
    }

    private void sendJson(HttpExchange exchange, int status, String json) throws IOException {
        byte[] bytes = json.getBytes(StandardCharsets.UTF_8);
        exchange.getResponseHeaders().set("Content-Type", "application/json; charset=utf-8");
        exchange.sendResponseHeaders(status, bytes.length);
        try (OutputStream os = exchange.getResponseBody()) {
            os.write(bytes);
        }
    }

    private void sendError(HttpExchange exchange, int status, String message) throws IOException {
        JSONObject json = new JSONObject();
        json.put("error", message);
        sendJson(exchange, status, json.toString());
    }
}
