package com.example.pdfsplit.standalone;

import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpHandler;
import org.json.JSONArray;
import org.json.JSONObject;

import java.io.IOException;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

public class SplitHandler implements HttpHandler {

    private final PdfSplitService service;

    public SplitHandler(PdfSplitService service) {
        this.service = service;
    }

    @Override
    public void handle(HttpExchange exchange) throws IOException {
        if (!"POST".equalsIgnoreCase(exchange.getRequestMethod())) {
            sendError(exchange, 405, "Method not allowed");
            return;
        }
        try {
            byte[] bodyBytes = exchange.getRequestBody().readAllBytes();
            String bodyText = new String(bodyBytes, StandardCharsets.UTF_8);
            JSONObject request = new JSONObject(bodyText);

            String filePath = request.getString("filePath");
            SplitMethod method = SplitMethod.valueOf(request.getString("method"));

            JSONArray rangesJson = request.getJSONArray("ranges");
            List<PageRange> ranges = new ArrayList<>();
            for (int i = 0; i < rangesJson.length(); i++) {
                JSONObject r = rangesJson.getJSONObject(i);
                ranges.add(new PageRange(r.getInt("fromPage"), r.getInt("toPage")));
            }

            List<SplitResult> results = service.split(filePath, method, ranges);

            JSONArray responseArray = new JSONArray();
            for (SplitResult r : results) {
                JSONObject obj = new JSONObject();
                obj.put("fromPage", r.getFromPage());
                obj.put("toPage", r.getToPage());
                obj.put("success", r.isSuccess());
                if (r.isSuccess()) {
                    obj.put("outputFileName", r.getOutputFileName());
                    obj.put("outputFilePath", r.getOutputFilePath());
                } else {
                    obj.put("errorMessage", r.getErrorMessage());
                }
                responseArray.put(obj);
            }

            sendJson(exchange, 200, responseArray.toString());

        } catch (PdfProcessingException e) {
            sendError(exchange, 400, e.getMessage());
        } catch (IllegalArgumentException e) {
            sendError(exchange, 400, "Invalid request: " + e.getMessage());
        } catch (Exception e) {
            sendError(exchange, 500, "Unexpected server error: " + e.getMessage());
        }
    }

    private void sendJson(HttpExchange exchange, int status, String json) throws IOException {
        byte[] bytes = json.getBytes(StandardCharsets.UTF_8);
        exchange.getResponseHeaders().set("Content-Type", "application/json; charset=utf-8");
        exchange.sendResponseHeaders(status, bytes.length);
        try (OutputStream os = exchange.getResponseBody()) {
            os.write(bytes);
        }
    }

    private void sendError(HttpExchange exchange, int status, String message) throws IOException {
        JSONObject json = new JSONObject();
        json.put("error", message);
        sendJson(exchange, status, json.toString());
    }
}
