package com.example.pdfsplit.standalone;

import org.apache.pdfbox.Loader;
import org.apache.pdfbox.multipdf.Splitter;
import org.apache.pdfbox.pdmodel.PDDocument;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import java.util.logging.Level;
import java.util.logging.Logger;

public class PdfSplitService {

    private static final Logger log = Logger.getLogger(PdfSplitService.class.getName());

    private final String uploadDir;
    private final int maxSplitsPerRequest;

    public PdfSplitService(String uploadDir, int maxSplitsPerRequest) {
        this.uploadDir = uploadDir;
        this.maxSplitsPerRequest = maxSplitsPerRequest;
    }

    /**
     * Saves the uploaded bytes to the upload directory and validates that the
     * result is a readable PDF, returning its absolute path and page count.
     */
    public StoredFile storeAndInspect(String originalFileName, byte[] fileBytes) {
        if (fileBytes == null || fileBytes.length == 0) {
            throw new PdfProcessingException("No file was uploaded.");
        }
        if (originalFileName == null || !originalFileName.toLowerCase().endsWith(".pdf")) {
            throw new PdfProcessingException("Only .pdf files are supported.");
        }

        try {
            Path uploadPath = Paths.get(uploadDir).toAbsolutePath().normalize();
            Files.createDirectories(uploadPath);

            String safeBaseName = sanitizeFileName(stripExtension(originalFileName));
            String storedName = safeBaseName + "_" + UUID.randomUUID() + ".pdf";
            Path targetPath = uploadPath.resolve(storedName);

            Files.write(targetPath, fileBytes);

            int totalPages;
            try (PDDocument doc = Loader.loadPDF(targetPath.toFile())) {
                totalPages = doc.getNumberOfPages();
            } catch (IOException e) {
                Files.deleteIfExists(targetPath);
                throw new PdfProcessingException("The uploaded file could not be read as a PDF. It may be corrupt or password-protected.", e);
            }

            return new StoredFile(originalFileName, targetPath.toAbsolutePath().toString(), totalPages);

        } catch (IOException e) {
            throw new PdfProcessingException("Failed to save uploaded file: " + e.getMessage(), e);
        }
    }

    /**
     * Validates ranges against the actual page count, then splits using
     * whichever PDFBox strategy was selected. One bad range is recorded as a
     * failure without aborting the rest of the batch.
     */
    public List<SplitResult> split(String filePath, SplitMethod method, List<PageRange> ranges) {
        if (ranges == null || ranges.isEmpty()) {
            throw new PdfProcessingException("At least one page range is required.");
        }
        if (ranges.size() > maxSplitsPerRequest) {
            throw new PdfProcessingException("No more than " + maxSplitsPerRequest + " page ranges are allowed per request.");
        }

        File sourceFile = new File(filePath);
        if (!sourceFile.exists() || !sourceFile.isFile()) {
            throw new PdfProcessingException("Source file no longer exists on the server: " + filePath);
        }

        List<SplitResult> results = new ArrayList<>();

        try (PDDocument sourceDoc = Loader.loadPDF(sourceFile)) {
            int totalPages = sourceDoc.getNumberOfPages();

            List<PageRange> validRanges = new ArrayList<>();
            for (PageRange range : ranges) {
                String validationError = validateRange(range, totalPages);
                if (validationError != null) {
                    results.add(SplitResult.failed(
                            range.getFromPage() == null ? 0 : range.getFromPage(),
                            range.getToPage() == null ? 0 : range.getToPage(),
                            validationError));
                } else {
                    validRanges.add(range);
                }
            }

            checkOverlaps(validRanges, results);

            for (PageRange range : ranges) {
                if (!validRanges.contains(range)) {
                    continue; // already recorded as failed above
                }
                try {
                    String outputPath = buildOutputPath(sourceFile, range.getFromPage(), range.getToPage());
                    File outputFile = new File(outputPath);

                    if (method == SplitMethod.SPLITTER) {
                        splitUsingSplitter(sourceFile, range, outputFile);
                    } else {
                        splitUsingImportPage(sourceDoc, range, outputFile);
                    }

                    results.add(SplitResult.ok(range.getFromPage(), range.getToPage(),
                            outputFile.getName(), outputFile.getAbsolutePath()));

                } catch (Exception e) {
                    log.log(Level.SEVERE, "Failed to split range " + range + " using " + method, e);
                    results.add(SplitResult.failed(range.getFromPage(), range.getToPage(),
                            "Failed to split this range: " + e.getMessage()));
                }
            }

        } catch (IOException e) {
            throw new PdfProcessingException("Failed to open source PDF: " + e.getMessage(), e);
        }

        return results;
    }

    private void splitUsingSplitter(File sourceFile, PageRange range, File outputFile) throws IOException {
        try (PDDocument doc = Loader.loadPDF(sourceFile)) {
            Splitter splitter = new Splitter();
            splitter.setStartPage(range.getFromPage());
            splitter.setEndPage(range.getToPage());
            splitter.setSplitAtPage(range.getToPage() - range.getFromPage() + 1);

            List<PDDocument> pieces = splitter.split(doc);
            if (pieces.isEmpty()) {
                throw new PdfProcessingException("Splitter produced no output for range " + range);
            }

            try (PDDocument result = pieces.get(0)) {
                result.save(outputFile);
            } finally {
                for (int i = 1; i < pieces.size(); i++) {
                    pieces.get(i).close();
                }
            }
        }
    }

    private void splitUsingImportPage(PDDocument sourceDoc, PageRange range, File outputFile) throws IOException {
        try (PDDocument outputDoc = new PDDocument()) {
            for (int pageNum = range.getFromPage(); pageNum <= range.getToPage(); pageNum++) {
                outputDoc.importPage(sourceDoc.getPage(pageNum - 1));
            }
            outputDoc.save(outputFile);
        }
    }

    private String validateRange(PageRange range, int totalPages) {
        if (range.getFromPage() == null || range.getToPage() == null) {
            return "fromPage and toPage are both required.";
        }
        if (range.getFromPage() < 1 || range.getToPage() < 1) {
            return "Page numbers must be 1 or greater.";
        }
        if (range.getFromPage() > range.getToPage()) {
            return "fromPage (" + range.getFromPage() + ") cannot be greater than toPage (" + range.getToPage() + ").";
        }
        if (range.getToPage() > totalPages) {
            return "toPage (" + range.getToPage() + ") exceeds the document's total pages (" + totalPages + ").";
        }
        return null;
    }

    private void checkOverlaps(List<PageRange> validRanges, List<SplitResult> results) {
        List<PageRange> toRemove = new ArrayList<>();
        for (int i = 0; i < validRanges.size(); i++) {
            for (int j = i + 1; j < validRanges.size(); j++) {
                PageRange a = validRanges.get(i);
                PageRange b = validRanges.get(j);
                boolean overlap = a.getFromPage() <= b.getToPage() && b.getFromPage() <= a.getToPage();
                if (overlap) {
                    String msg = "Overlaps with another requested range (" + b.getFromPage() + "-" + b.getToPage() + ").";
                    results.add(SplitResult.failed(a.getFromPage(), a.getToPage(), msg));
                    toRemove.add(a);
                }
            }
        }
        validRanges.removeAll(toRemove);
    }

    private String buildOutputPath(File sourceFile, int fromPage, int toPage) {
        File parentDir = sourceFile.getParentFile();
        String parentPath = (parentDir != null) ? parentDir.getAbsolutePath() : ".";

        String fileName = sourceFile.getName();
        int dotIndex = fileName.lastIndexOf('.');
        String baseName = dotIndex > 0 ? fileName.substring(0, dotIndex) : fileName;
        String extension = dotIndex > 0 ? fileName.substring(dotIndex) : "";

        baseName = baseName.replaceFirst("_[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$", "");

        String newFileName = baseName + "_" + fromPage + "_" + toPage + extension;
        return parentPath + File.separator + newFileName;
    }

    private String stripExtension(String fileName) {
        int dotIndex = fileName.lastIndexOf('.');
        return dotIndex > 0 ? fileName.substring(0, dotIndex) : fileName;
    }

    private String sanitizeFileName(String name) {
        return name.replaceAll("[^a-zA-Z0-9-_]", "_");
    }

    public static class StoredFile {
        private final String originalFileName;
        private final String filePath;
        private final int totalPages;

        public StoredFile(String originalFileName, String filePath, int totalPages) {
            this.originalFileName = originalFileName;
            this.filePath = filePath;
            this.totalPages = totalPages;
        }

        public String getOriginalFileName() {
            return originalFileName;
        }

        public String getFilePath() {
            return filePath;
        }

        public int getTotalPages() {
            return totalPages;
        }
    }
}
