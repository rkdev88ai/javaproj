package com.example.pdfsplit.standalone;

import com.sun.net.httpserver.HttpServer;

import java.awt.Desktop;
import java.io.File;
import java.io.IOException;
import java.net.InetSocketAddress;
import java.net.URI;
import java.util.concurrent.Executors;

/**
 * Standalone entry point. No Spring Boot, no application server — just the
 * JDK's built-in com.sun.net.httpserver.HttpServer, serving both the static
 * web UI (from src/main/resources/webapp, bundled into this jar) and the two
 * REST-style endpoints the UI calls.
 *
 * Run with:  java -jar pdf-split-standalone.jar [uploadDir]
 * If uploadDir is omitted, "./uploads" (relative to wherever you launch it
 * from) is used.
 */
public class Main {

    public static final int PORT = 8080;
    public static final int MAX_SPLITS_PER_REQUEST = 5;

    public static void main(String[] args) throws IOException {
        String uploadDir = args.length > 0 ? args[0] : "./uploads";
        PdfSplitService service = new PdfSplitService(uploadDir, MAX_SPLITS_PER_REQUEST);

        HttpServer server = HttpServer.create(new InetSocketAddress(PORT), 0);
        server.setExecutor(Executors.newFixedThreadPool(8));

        server.createContext("/api/pdf/upload", new UploadHandler(service));
        server.createContext("/api/pdf/split", new SplitHandler(service));
        server.createContext("/", new StaticFileHandler());

        server.start();

        String url = "http://localhost:" + PORT + "/";
        System.out.println("Document Splitter is running at " + url);
        System.out.println("Upload / output directory: " + new File(uploadDir).getAbsolutePath());
        System.out.println("Press Ctrl+C to stop.");

        openBrowser(url);
    }

    private static void openBrowser(String url) {
        try {
            if (Desktop.isDesktopSupported() && Desktop.getDesktop().isSupported(Desktop.Action.BROWSE)) {
                Desktop.getDesktop().browse(URI.create(url));
            } else {
                System.out.println("Open " + url + " in your browser.");
            }
        } catch (Exception e) {
            System.out.println("Could not open a browser automatically. Open " + url + " manually.");
        }
    }
}
