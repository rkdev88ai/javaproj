package com.example.pdfsplit.standalone;

public class PageRange {

    private final Integer fromPage;
    private final Integer toPage;

    public PageRange(Integer fromPage, Integer toPage) {
        this.fromPage = fromPage;
        this.toPage = toPage;
    }

    public Integer getFromPage() {
        return fromPage;
    }

    public Integer getToPage() {
        return toPage;
    }

    @Override
    public String toString() {
        return "PageRange{" + fromPage + " -> " + toPage + "}";
    }
}
