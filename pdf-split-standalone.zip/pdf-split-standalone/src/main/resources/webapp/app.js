const MAX_RANGES = 5;

const state = {
  filePath: null,
  originalFileName: null,
  totalPages: null,
  ranges: [{ from: '', to: '' }],
  method: 'IMPORT_PAGE',
};

const dropzone = document.getElementById('dropzone');
const fileInput = document.getElementById('fileInput');
const uploadStatus = document.getElementById('uploadStatus');
const uploadError = document.getElementById('uploadError');
const intakeSummary = document.getElementById('intakeSummary');
const summaryFileName = document.getElementById('summaryFileName');
const summaryTotalPages = document.getElementById('summaryTotalPages');
const afterUpload = document.getElementById('afterUpload');
const rangeList = document.getElementById('rangeList');
const rangeCount = document.getElementById('rangeCount');
const addRangeBtn = document.getElementById('addRangeBtn');
const submitBtn = document.getElementById('submitBtn');
const submitError = document.getElementById('submitError');
const resultsPanel = document.getElementById('resultsPanel');
const manifestList = document.getElementById('manifestList');
const manifestCount = document.getElementById('manifestCount');
const methodLabelSplitter = document.getElementById('methodLabelSplitter');
const methodLabelImport = document.getElementById('methodLabelImport');

function show(el) { el.hidden = false; }
function hide(el) { el.hidden = true; }

dropzone.addEventListener('click', () => fileInput.click());
dropzone.addEventListener('keydown', (e) => {
  if (e.key === 'Enter') fileInput.click();
});
dropzone.addEventListener('dragover', (e) => {
  e.preventDefault();
  dropzone.classList.add('dropzone--active');
});
dropzone.addEventListener('dragleave', () => dropzone.classList.remove('dropzone--active'));
dropzone.addEventListener('drop', (e) => {
  e.preventDefault();
  dropzone.classList.remove('dropzone--active');
  if (e.dataTransfer.files && e.dataTransfer.files[0]) {
    handleFile(e.dataTransfer.files[0]);
  }
});
fileInput.addEventListener('change', (e) => {
  if (e.target.files && e.target.files[0]) handleFile(e.target.files[0]);
});

async function handleFile(file) {
  hide(uploadError);
  hide(intakeSummary);
  hide(afterUpload);
  hide(resultsPanel);
  uploadStatus.textContent = 'Uploading and reading page count\u2026';
  show(uploadStatus);

  const formData = new FormData();
  formData.append('file', file);

  try {
    const response = await fetch('/api/pdf/upload', { method: 'POST', body: formData });
    const body = await response.json();
    if (!response.ok) throw new Error(body.error || 'Upload failed.');

    state.filePath = body.filePath;
    state.originalFileName = body.originalFileName;
    state.totalPages = body.totalPages;
    state.ranges = [{ from: '', to: '' }];

    summaryFileName.textContent = body.originalFileName;
    summaryTotalPages.textContent = String(body.totalPages);
    show(intakeSummary);
    show(afterUpload);
    renderRanges();
  } catch (err) {
    uploadError.textContent = err.message;
    show(uploadError);
  } finally {
    hide(uploadStatus);
  }
}

function validateRange(range) {
  if (range.from === '' || range.to === '') return null;
  const from = Number(range.from);
  const to = Number(range.to);
  if (!Number.isInteger(from) || !Number.isInteger(to)) return 'Page numbers must be whole numbers.';
  if (from < 1 || to < 1) return 'Page numbers must be 1 or greater.';
  if (from > to) return `From (${from}) cannot be greater than To (${to}).`;
  if (state.totalPages && to > state.totalPages) return `To (${to}) exceeds the document's ${state.totalPages} pages.`;
  return null;
}

function buildField(labelText, value, onChange) {
  const label = document.createElement('label');
  label.className = 'range-field';

  const span = document.createElement('span');
  span.className = 'range-label';
  span.textContent = labelText;
  label.appendChild(span);

  const input = document.createElement('input');
  input.type = 'number';
  input.min = '1';
  if (state.totalPages) input.max = String(state.totalPages);
  input.className = 'mono';
  input.value = value;
  input.addEventListener('input', (e) => onChange(e.target.value));
  label.appendChild(input);

  return label;
}

function renderRanges() {
  rangeList.innerHTML = '';

  state.ranges.forEach((range, index) => {
    const error = validateRange(range);

    const row = document.createElement('div');
    row.className = 'range-row';

    const idx = document.createElement('span');
    idx.className = 'range-index';
    idx.textContent = String(index + 1);
    row.appendChild(idx);

    row.appendChild(buildField('From page', range.from, (val) => {
      state.ranges[index].from = val;
      renderRanges();
    }));

    const arrow = document.createElement('span');
    arrow.className = 'range-arrow';
    arrow.textContent = '\u2192';
    row.appendChild(arrow);

    row.appendChild(buildField('To page', range.to, (val) => {
      state.ranges[index].to = val;
      renderRanges();
    }));

    const removeBtn = document.createElement('button');
    removeBtn.type = 'button';
    removeBtn.className = 'row-remove';
    removeBtn.textContent = 'Remove';
    removeBtn.disabled = state.ranges.length === 1;
    removeBtn.title = state.ranges.length === 1 ? 'At least one range is required' : 'Remove this range';
    removeBtn.addEventListener('click', () => {
      state.ranges.splice(index, 1);
      renderRanges();
    });
    row.appendChild(removeBtn);

    if (error) {
      const errEl = document.createElement('p');
      errEl.className = 'range-error';
      errEl.textContent = error;
      row.appendChild(errEl);
    }

    rangeList.appendChild(row);
  });

  rangeCount.textContent = `${state.ranges.length} of ${MAX_RANGES} used`;
  addRangeBtn.disabled = state.ranges.length >= MAX_RANGES;
  updateSubmitState();
}

addRangeBtn.addEventListener('click', () => {
  if (state.ranges.length >= MAX_RANGES) return;
  state.ranges.push({ from: '', to: '' });
  renderRanges();
});

[methodLabelSplitter, methodLabelImport].forEach((label) => {
  label.addEventListener('click', () => {
    const value = label.querySelector('input').value;
    state.method = value;
    methodLabelSplitter.classList.toggle('method-option--active', value === 'SPLITTER');
    methodLabelImport.classList.toggle('method-option--active', value === 'IMPORT_PAGE');
  });
});

function rangesAreValid() {
  if (state.ranges.length === 0) return false;
  return state.ranges.every((r) => r.from !== '' && r.to !== '' && validateRange(r) === null);
}

function updateSubmitState() {
  submitBtn.disabled = !rangesAreValid();
}

submitBtn.addEventListener('click', async () => {
  if (!rangesAreValid()) return;
  hide(submitError);
  hide(resultsPanel);
  submitBtn.disabled = true;
  submitBtn.textContent = 'Splitting\u2026';

  const payload = {
    filePath: state.filePath,
    method: state.method,
    ranges: state.ranges.map((r) => ({ fromPage: Number(r.from), toPage: Number(r.to) })),
  };

  try {
    const response = await fetch('/api/pdf/split', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload),
    });
    const body = await response.json();
    if (!response.ok) throw new Error(body.error || 'Split request failed.');
    renderResults(body);
  } catch (err) {
    submitError.textContent = err.message;
    show(submitError);
  } finally {
    submitBtn.textContent = 'Split document';
    updateSubmitState();
  }
});

function renderResults(results) {
  manifestList.innerHTML = '';
  const successCount = results.filter((r) => r.success).length;
  manifestCount.textContent = `${successCount} of ${results.length} written`;

  results.forEach((result) => {
    const li = document.createElement('li');
    li.className = 'manifest-item ' + (result.success ? 'manifest-item--ok' : 'manifest-item--failed');

    const mark = document.createElement('span');
    mark.className = 'manifest-mark';
    mark.textContent = result.success ? '\u2713' : '\u2715';
    li.appendChild(mark);

    const body = document.createElement('div');
    body.className = 'manifest-body';

    const range = document.createElement('span');
    range.className = 'manifest-range mono';
    range.textContent = `pages ${result.fromPage}\u2013${result.toPage}`;
    body.appendChild(range);

    if (result.success) {
      const path = document.createElement('span');
      path.className = 'manifest-path mono';
      path.textContent = result.outputFilePath;
      body.appendChild(path);
    } else {
      const err = document.createElement('span');
      err.className = 'manifest-error';
      err.textContent = result.errorMessage;
      body.appendChild(err);
    }

    li.appendChild(body);
    manifestList.appendChild(li);
  });

  show(resultsPanel);
}
