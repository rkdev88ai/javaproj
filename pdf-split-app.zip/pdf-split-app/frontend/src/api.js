// Uses the CRA dev-server "proxy" field in package.json to reach the Spring Boot
// backend on :8080 without hitting CORS during local development. In production,
// point these at your deployed API's absolute base URL instead.

export async function uploadFile(file) {
  const formData = new FormData();
  formData.append('file', file);

  const response = await fetch('/api/pdf/upload', {
    method: 'POST',
    body: formData,
  });

  const body = await response.json();
  if (!response.ok) {
    throw new Error(body.error || 'Upload failed.');
  }
  return body; // { originalFileName, filePath, totalPages }
}

export async function splitFile({ filePath, method, ranges }) {
  const response = await fetch('/api/pdf/split', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ filePath, method, ranges }),
  });

  const body = await response.json();
  if (!response.ok) {
    throw new Error(body.error || 'Split request failed.');
  }
  return body; // SplitResult[]
}
