import React from 'react';

const MAX_RANGES = 5;

function validateRange(range, totalPages) {
  const { fromPage, toPage } = range;
  if (fromPage === '' || toPage === '') {
    return null; // not filled in yet — don't show an error until they've typed something
  }
  const from = Number(fromPage);
  const to = Number(toPage);
  if (!Number.isInteger(from) || !Number.isInteger(to)) {
    return 'Page numbers must be whole numbers.';
  }
  if (from < 1 || to < 1) {
    return 'Page numbers must be 1 or greater.';
  }
  if (from > to) {
    return `From (${from}) cannot be greater than To (${to}).`;
  }
  if (totalPages && to > totalPages) {
    return `To (${to}) exceeds the document's ${totalPages} pages.`;
  }
  return null;
}

export default function PageRangeForm({ ranges, totalPages, onChange }) {
  function updateRange(index, field, value) {
    const next = ranges.map((r, i) => (i === index ? { ...r, [field]: value } : r));
    onChange(next);
  }

  function addRow() {
    if (ranges.length >= MAX_RANGES) return;
    onChange([...ranges, { fromPage: '', toPage: '' }]);
  }

  function removeRow(index) {
    onChange(ranges.filter((_, i) => i !== index));
  }

  return (
    <section className="panel">
      <div className="panel-title-row">
        <h2 className="panel-title">2. Page ranges</h2>
        <span className="panel-note">{ranges.length} of {MAX_RANGES} used</span>
      </div>

      <div className="range-list">
        {ranges.map((range, index) => {
          const error = validateRange(range, totalPages);
          return (
            <div className="range-row" key={index}>
              <span className="range-index">{index + 1}</span>

              <label className="range-field">
                <span className="range-label">From page</span>
                <input
                  type="number"
                  min="1"
                  max={totalPages || undefined}
                  className="mono"
                  value={range.fromPage}
                  onChange={(e) => updateRange(index, 'fromPage', e.target.value)}
                />
              </label>

              <span className="range-arrow">&rarr;</span>

              <label className="range-field">
                <span className="range-label">To page</span>
                <input
                  type="number"
                  min="1"
                  max={totalPages || undefined}
                  className="mono"
                  value={range.toPage}
                  onChange={(e) => updateRange(index, 'toPage', e.target.value)}
                />
              </label>

              <button
                type="button"
                className="row-remove"
                onClick={() => removeRow(index)}
                aria-label={`Remove range ${index + 1}`}
                disabled={ranges.length === 1}
                title={ranges.length === 1 ? 'At least one range is required' : 'Remove this range'}
              >
                Remove
              </button>

              {error && <p className="range-error">{error}</p>}
            </div>
          );
        })}
      </div>

      <button
        type="button"
        className="add-row-btn"
        onClick={addRow}
        disabled={ranges.length >= MAX_RANGES}
      >
        + Add another range
      </button>
    </section>
  );
}

export { validateRange, MAX_RANGES };
