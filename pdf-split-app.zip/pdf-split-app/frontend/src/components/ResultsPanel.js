import React from 'react';

export default function ResultsPanel({ results }) {
  if (!results || results.length === 0) return null;

  const successCount = results.filter((r) => r.success).length;

  return (
    <section className="panel results">
      <div className="panel-title-row">
        <h2 className="panel-title">Manifest</h2>
        <span className="panel-note">{successCount} of {results.length} written</span>
      </div>

      <ul className="manifest-list">
        {results.map((result, index) => (
          <li key={index} className={`manifest-item ${result.success ? 'manifest-item--ok' : 'manifest-item--failed'}`}>
            <span className="manifest-mark">{result.success ? '✓' : '✕'}</span>
            <div className="manifest-body">
              <span className="manifest-range mono">
                pages {result.fromPage}&ndash;{result.toPage}
              </span>
              {result.success ? (
                <span className="manifest-path mono">{result.outputFilePath}</span>
              ) : (
                <span className="manifest-error">{result.errorMessage}</span>
              )}
            </div>
          </li>
        ))}
      </ul>
    </section>
  );
}
