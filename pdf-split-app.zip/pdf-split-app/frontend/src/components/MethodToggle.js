import React from 'react';

const OPTIONS = [
  {
    value: 'SPLITTER',
    label: 'Splitter',
    description: 'org.apache.pdfbox.multipdf.Splitter — fewer lines of code per range.',
  },
  {
    value: 'IMPORT_PAGE',
    label: 'Import page',
    description: 'PDDocument.importPage() per page — avoids Splitter\u2019s clone/structure-tree path.',
  },
];

export default function MethodToggle({ value, onChange }) {
  return (
    <section className="panel">
      <h2 className="panel-title">3. Split method</h2>
      <div className="method-toggle" role="radiogroup" aria-label="PDFBox split method">
        {OPTIONS.map((option) => (
          <label
            key={option.value}
            className={`method-option ${value === option.value ? 'method-option--active' : ''}`}
          >
            <input
              type="radio"
              name="split-method"
              value={option.value}
              checked={value === option.value}
              onChange={() => onChange(option.value)}
            />
            <span className="method-label">{option.label}</span>
            <span className="method-description">{option.description}</span>
          </label>
        ))}
      </div>
    </section>
  );
}
