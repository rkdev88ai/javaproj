import React, { useRef, useState } from 'react';

export default function FileUploadPanel({ onFileSelected, uploading, uploadedInfo }) {
  const inputRef = useRef(null);
  const [dragActive, setDragActive] = useState(false);

  function handleFiles(fileList) {
    const file = fileList && fileList[0];
    if (file) {
      onFileSelected(file);
    }
  }

  return (
    <section className="panel intake">
      <h2 className="panel-title">1. Source file</h2>

      <div
        className={`dropzone ${dragActive ? 'dropzone--active' : ''}`}
        onClick={() => inputRef.current && inputRef.current.click()}
        onDragOver={(e) => { e.preventDefault(); setDragActive(true); }}
        onDragLeave={() => setDragActive(false)}
        onDrop={(e) => {
          e.preventDefault();
          setDragActive(false);
          handleFiles(e.dataTransfer.files);
        }}
        role="button"
        tabIndex={0}
        onKeyDown={(e) => { if (e.key === 'Enter') inputRef.current.click(); }}
      >
        <input
          ref={inputRef}
          type="file"
          accept="application/pdf"
          hidden
          onChange={(e) => handleFiles(e.target.files)}
        />
        <p className="dropzone-instruction">
          Drop a PDF here, or click to choose a file
        </p>
        <p className="dropzone-hint">PDF only, up to 100&nbsp;MB</p>
      </div>

      {uploading && <p className="status-line">Uploading and reading page count…</p>}

      {uploadedInfo && !uploading && (
        <dl className="intake-summary">
          <div>
            <dt>File</dt>
            <dd className="mono">{uploadedInfo.originalFileName}</dd>
          </div>
          <div>
            <dt>Total pages</dt>
            <dd className="mono">{uploadedInfo.totalPages}</dd>
          </div>
        </dl>
      )}
    </section>
  );
}
