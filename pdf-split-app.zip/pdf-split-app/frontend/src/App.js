import React, { useState } from 'react';
import './App.css';
import FileUploadPanel from './components/FileUploadPanel';
import PageRangeForm, { validateRange } from './components/PageRangeForm';
import MethodToggle from './components/MethodToggle';
import ResultsPanel from './components/ResultsPanel';
import { uploadFile, splitFile } from './api';

export default function App() {
  const [uploading, setUploading] = useState(false);
  const [uploadedInfo, setUploadedInfo] = useState(null); // { originalFileName, filePath, totalPages }
  const [uploadError, setUploadError] = useState(null);

  const [ranges, setRanges] = useState([{ fromPage: '', toPage: '' }]);
  const [method, setMethod] = useState('IMPORT_PAGE');

  const [submitting, setSubmitting] = useState(false);
  const [submitError, setSubmitError] = useState(null);
  const [results, setResults] = useState(null);

  async function handleFileSelected(file) {
    setUploading(true);
    setUploadError(null);
    setUploadedInfo(null);
    setResults(null);
    try {
      const info = await uploadFile(file);
      setUploadedInfo(info);
    } catch (err) {
      setUploadError(err.message);
    } finally {
      setUploading(false);
    }
  }

  function rangesAreValid() {
    if (ranges.length === 0) return false;
    return ranges.every((r) => {
      if (r.fromPage === '' || r.toPage === '') return false;
      return validateRange(r, uploadedInfo ? uploadedInfo.totalPages : null) === null;
    });
  }

  async function handleSubmit() {
    if (!uploadedInfo || !rangesAreValid()) return;
    setSubmitting(true);
    setSubmitError(null);
    setResults(null);
    try {
      const payload = {
        filePath: uploadedInfo.filePath,
        method,
        ranges: ranges.map((r) => ({ fromPage: Number(r.fromPage), toPage: Number(r.toPage) })),
      };
      const outcome = await splitFile(payload);
      setResults(outcome);
    } catch (err) {
      setSubmitError(err.message);
    } finally {
      setSubmitting(false);
    }
  }

  const canSubmit = uploadedInfo && rangesAreValid() && !submitting;

  return (
    <div className="page">
      <header className="masthead">
        <span className="masthead-mark">&sect;</span>
        <h1>Document Splitter</h1>
        <p className="masthead-sub">
          Upload a PDF, mark up to five page ranges, and issue split copies into the same folder.
        </p>
      </header>

      <main className="sheet">
        <FileUploadPanel
          onFileSelected={handleFileSelected}
          uploading={uploading}
          uploadedInfo={uploadedInfo}
        />
        {uploadError && <p className="banner banner--error">{uploadError}</p>}

        {uploadedInfo && (
          <>
            <PageRangeForm
              ranges={ranges}
              totalPages={uploadedInfo.totalPages}
              onChange={setRanges}
            />

            <MethodToggle value={method} onChange={setMethod} />

            <div className="submit-row">
              <button
                type="button"
                className="submit-btn"
                disabled={!canSubmit}
                onClick={handleSubmit}
              >
                {submitting ? 'Splitting…' : 'Split document'}
              </button>
            </div>

            {submitError && <p className="banner banner--error">{submitError}</p>}
          </>
        )}

        <ResultsPanel results={results} />
      </main>

      <footer className="foot-note">
        PDFBox 3.0.8 &middot; runs locally against files on this server's file system
      </footer>
    </div>
  );
}
