# Document Splitter — PDF page-range split tool

An enterprise-style PDF splitting tool: a React front end for upload + page-range
entry, and a Spring Boot backend that uses Apache PDFBox 3.0.8 to perform the
split. Users can choose, per request, which PDFBox strategy is used to write
the output files:

- **Splitter** — `org.apache.pdfbox.multipdf.Splitter`
- **Import page** — `PDDocument.importPage()` per page (avoids Splitter's
  clone/structure-tree code path, which had corruption bugs in some PDFBox
  3.0.x patch releases)

Up to 5 from/to page ranges can be submitted per file. Each range is written
as a new PDF into the **same folder as the source file**, named
`<original-name>_<fromPage>_<toPage>.pdf`.

## Project layout

```
pdf-split-app/
  backend/    Spring Boot 3 + PDFBox 3.0.8 REST API
  frontend/   React app (Create React App)
```

## Running the backend

Requires JDK 17+ and Maven.

```
cd backend
mvn spring-boot:run
```

The API starts on `http://localhost:8080`. Uploaded files are stored under
`./uploads` relative to wherever you run the command (configurable via
`app.upload-dir` in `src/main/resources/application.properties`) — this is
also the folder split output files are written into, since split files are
written next to the source file.

To use PDFBox 3.0.3 instead of 3.0.8, edit the single `<pdfbox.version>`
property near the top of `backend/pom.xml`.

### Endpoints

- `POST /api/pdf/upload` — multipart form field `file`. Returns
  `{ originalFileName, filePath, totalPages }`.
- `POST /api/pdf/split` — JSON body:
  ```json
  {
    "filePath": "C:\\...\\uploads\\statement_<uuid>.pdf",
    "method": "SPLITTER",
    "ranges": [{ "fromPage": 1, "toPage": 3 }, { "fromPage": 4, "toPage": 6 }]
  }
  ```
  `method` is either `SPLITTER` or `IMPORT_PAGE`. Returns an array of
  per-range results, each either successful (with the output file path) or
  failed (with a reason) — one bad range does not block the others.

## Running the frontend

Requires Node.js 18+.

```
cd frontend
npm install
npm start
```

Opens at `http://localhost:3000`. The dev server proxies `/api/*` calls to
`http://localhost:8080` (see the `"proxy"` field in `frontend/package.json`),
so no CORS configuration is needed in local development. `backend/.../WebConfig.java`
also allows `http://localhost:3000` directly, for setups that don't use the
CRA proxy.

## Validation rules enforced server-side

- Uploaded file must be a `.pdf` and must open successfully with PDFBox
  (rejects corrupt/password-protected files with a clear error).
- 1 to 5 ranges per request.
- Each range: `fromPage`/`toPage` ≥ 1, `fromPage` ≤ `toPage`, `toPage` ≤ the
  document's actual page count.
- Overlapping ranges (e.g. 1–3 and 2–4) are flagged as failed rather than
  silently producing overlapping output files.

The React UI mirrors the range/page-count checks client-side for immediate
feedback, but the backend re-validates independently — never trust client-side
checks alone for a file-system-writing operation.

## Notes on the two split strategies

Both are implemented in `PdfSplitService`. `IMPORT_PAGE` is selected as the
frontend's default, since it doesn't depend on PDFBox's `Splitter` clone path.
The `SPLITTER` option is included so you can compare behavior/output directly
against `IMPORT_PAGE`, or use it once you've upgraded to a PDFBox version
where the known `Splitter` issues (e.g. PDFBOX-5742) are fixed.
