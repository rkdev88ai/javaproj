package com.example.pdfsplit.config;

import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.CorsRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

/**
 * Allows the React development server (typically http://localhost:3000) to call
 * this API (typically http://localhost:8080) during local development.
 *
 * In production, replace "http://localhost:3000" with your actual deployed
 * front-end origin, or serve the built React app from this same Spring Boot
 * app so no cross-origin call is needed at all.
 */
@Configuration
public class WebConfig implements WebMvcConfigurer {

    @Override
    public void addCorsMappings(CorsRegistry registry) {
        registry.addMapping("/api/**")
                .allowedOrigins("http://localhost:3000")
                .allowedMethods("GET", "POST", "OPTIONS")
                .allowedHeaders("*");
    }
}
