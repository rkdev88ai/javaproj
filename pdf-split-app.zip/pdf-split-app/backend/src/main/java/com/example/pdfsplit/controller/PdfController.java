package com.example.pdfsplit.controller;

import com.example.pdfsplit.model.SplitRequest;
import com.example.pdfsplit.model.SplitResult;
import com.example.pdfsplit.model.UploadResponse;
import com.example.pdfsplit.service.PdfSplitService;
import jakarta.validation.Valid;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;

@RestController
@RequestMapping("/api/pdf")
public class PdfController {

    private final PdfSplitService pdfSplitService;

    public PdfController(PdfSplitService pdfSplitService) {
        this.pdfSplitService = pdfSplitService;
    }

    /**
     * Step 1: upload the source PDF. Stores it server-side and returns its
     * total page count so the UI can validate from/to page inputs client-side
     * before the user submits the split request.
     */
    @PostMapping(value = "/upload", consumes = "multipart/form-data")
    public UploadResponse upload(@RequestParam("file") MultipartFile file) {
        PdfSplitService.StoredFile stored = pdfSplitService.storeAndInspect(file);
        return new UploadResponse(stored.getOriginalFileName(), stored.getFilePath(), stored.getTotalPages());
    }

    /**
     * Step 2: split the previously uploaded file (identified by filePath) into
     * up to 5 page ranges, using whichever PDFBox strategy the user chose.
     */
    @PostMapping("/split")
    public List<SplitResult> split(@Valid @RequestBody SplitRequest request) {
        return pdfSplitService.split(request.getFilePath(), request.getMethod(), request.getRanges());
    }
}
