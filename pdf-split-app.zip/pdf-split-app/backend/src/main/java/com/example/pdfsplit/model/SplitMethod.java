package com.example.pdfsplit.model;

/**
 * Which PDFBox strategy to use for producing each split file.
 *
 * SPLITTER    - org.apache.pdfbox.multipdf.Splitter (setStartPage/setEndPage/setSplitAtPage).
 *               Simpler call, but historically had corruption bugs in some PDFBox 3.0.x
 *               patch releases (e.g. PDFBOX-5742), fixed by 3.0.2/3.0.3.
 * IMPORT_PAGE - Builds a new PDDocument and calls PDDocument.importPage() for each page
 *               in the range. More verbose, but uses the same well-exercised code path
 *               PDFMergerUtility relies on, and avoids Splitter's structure-tree/clone logic.
 */
public enum SplitMethod {
    SPLITTER,
    IMPORT_PAGE
}
