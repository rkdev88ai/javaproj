package com.example.pdfsplit.model;

public class SplitResult {

    private int fromPage;
    private int toPage;
    private String outputFileName;
    private String outputFilePath;
    private boolean success;
    private String errorMessage;

    public static SplitResult ok(int fromPage, int toPage, String outputFileName, String outputFilePath) {
        SplitResult r = new SplitResult();
        r.fromPage = fromPage;
        r.toPage = toPage;
        r.outputFileName = outputFileName;
        r.outputFilePath = outputFilePath;
        r.success = true;
        return r;
    }

    public static SplitResult failed(int fromPage, int toPage, String errorMessage) {
        SplitResult r = new SplitResult();
        r.fromPage = fromPage;
        r.toPage = toPage;
        r.success = false;
        r.errorMessage = errorMessage;
        return r;
    }

    public int getFromPage() {
        return fromPage;
    }

    public int getToPage() {
        return toPage;
    }

    public String getOutputFileName() {
        return outputFileName;
    }

    public String getOutputFilePath() {
        return outputFilePath;
    }

    public boolean isSuccess() {
        return success;
    }

    public String getErrorMessage() {
        return errorMessage;
    }
}
