package com.example.pdfsplit.model;

public class UploadResponse {

    private String originalFileName;
    private String filePath;
    private int totalPages;

    public UploadResponse(String originalFileName, String filePath, int totalPages) {
        this.originalFileName = originalFileName;
        this.filePath = filePath;
        this.totalPages = totalPages;
    }

    public String getOriginalFileName() {
        return originalFileName;
    }

    public String getFilePath() {
        return filePath;
    }

    public int getTotalPages() {
        return totalPages;
    }
}
