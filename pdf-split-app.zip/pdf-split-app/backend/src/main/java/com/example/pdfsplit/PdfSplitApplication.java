package com.example.pdfsplit;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PdfSplitApplication {

    public static void main(String[] args) {
        SpringApplication.run(PdfSplitApplication.class, args);
    }
}
