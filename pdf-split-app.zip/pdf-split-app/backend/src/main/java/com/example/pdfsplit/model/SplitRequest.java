package com.example.pdfsplit.model;

import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;

import java.util.List;

public class SplitRequest {

    @NotBlank(message = "filePath is required")
    private String filePath;

    @NotNull(message = "method is required")
    private SplitMethod method;

    @NotEmpty(message = "At least one page range is required")
    @Size(max = 5, message = "No more than 5 page ranges are allowed per request")
    @Valid
    private List<PageRange> ranges;

    public String getFilePath() {
        return filePath;
    }

    public void setFilePath(String filePath) {
        this.filePath = filePath;
    }

    public SplitMethod getMethod() {
        return method;
    }

    public void setMethod(SplitMethod method) {
        this.method = method;
    }

    public List<PageRange> getRanges() {
        return ranges;
    }

    public void setRanges(List<PageRange> ranges) {
        this.ranges = ranges;
    }
}
