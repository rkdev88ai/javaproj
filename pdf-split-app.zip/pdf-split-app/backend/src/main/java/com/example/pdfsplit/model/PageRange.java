package com.example.pdfsplit.model;

import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotNull;

public class PageRange {

    @NotNull(message = "fromPage is required")
    @Min(value = 1, message = "fromPage must be 1 or greater")
    private Integer fromPage;

    @NotNull(message = "toPage is required")
    @Min(value = 1, message = "toPage must be 1 or greater")
    private Integer toPage;

    public PageRange() {
    }

    public PageRange(Integer fromPage, Integer toPage) {
        this.fromPage = fromPage;
        this.toPage = toPage;
    }

    public Integer getFromPage() {
        return fromPage;
    }

    public void setFromPage(Integer fromPage) {
        this.fromPage = fromPage;
    }

    public Integer getToPage() {
        return toPage;
    }

    public void setToPage(Integer toPage) {
        this.toPage = toPage;
    }

    @Override
    public String toString() {
        return "PageRange{" + fromPage + " -> " + toPage + "}";
    }
}
