package com.example.pdfsplit.service;

import com.example.pdfsplit.exception.PdfProcessingException;
import com.example.pdfsplit.model.PageRange;
import com.example.pdfsplit.model.SplitMethod;
import com.example.pdfsplit.model.SplitResult;
import org.apache.pdfbox.Loader;
import org.apache.pdfbox.multipdf.Splitter;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

@Service
public class PdfSplitService {

    private static final Logger log = LoggerFactory.getLogger(PdfSplitService.class);

    @Value("${app.upload-dir}")
    private String uploadDir;

    @Value("${app.max-splits-per-request:5}")
    private int maxSplitsPerRequest;

    /**
     * Saves the uploaded multipart file to the configured upload directory and
     * validates that it is actually a readable PDF. Returns the stored file's
     * absolute path and total page count so the UI can validate from/to page
     * inputs before the user submits a split request.
     */
    public StoredFile storeAndInspect(MultipartFile file) {
        if (file == null || file.isEmpty()) {
            throw new PdfProcessingException("No file was uploaded.");
        }

        String originalName = file.getOriginalFilename();
        if (originalName == null || !originalName.toLowerCase().endsWith(".pdf")) {
            throw new PdfProcessingException("Only .pdf files are supported.");
        }

        try {
            Path uploadPath = Paths.get(uploadDir).toAbsolutePath().normalize();
            Files.createDirectories(uploadPath);

            // Store under a unique name to avoid collisions between concurrent users
            // uploading files with the same original name, while keeping the original
            // name recognizable for the split-output naming step.
            String safeBaseName = sanitizeFileName(stripExtension(originalName));
            String storedName = safeBaseName + "_" + UUID.randomUUID() + ".pdf";
            Path targetPath = uploadPath.resolve(storedName);

            file.transferTo(targetPath);

            int totalPages;
            try (PDDocument doc = Loader.loadPDF(targetPath.toFile())) {
                totalPages = doc.getNumberOfPages();
            } catch (IOException e) {
                Files.deleteIfExists(targetPath);
                throw new PdfProcessingException("The uploaded file could not be read as a PDF. It may be corrupt or password-protected.", e);
            }

            return new StoredFile(originalName, targetPath.toAbsolutePath().toString(), totalPages);

        } catch (IOException e) {
            throw new PdfProcessingException("Failed to save uploaded file: " + e.getMessage(), e);
        }
    }

    /**
     * Validates the requested ranges against the actual page count, then splits
     * using whichever PDFBox strategy the user selected. Each output file is
     * written into the same folder as the source file, named
     * "<original base name>_<fromPage>_<toPage>.pdf".
     *
     * One bad range does not abort the whole batch: it is recorded as a failed
     * SplitResult and the remaining ranges are still attempted, so the user gets
     * a complete picture of what succeeded and what didn't.
     */
    public List<SplitResult> split(String filePath, SplitMethod method, List<PageRange> ranges) {
        if (ranges == null || ranges.isEmpty()) {
            throw new PdfProcessingException("At least one page range is required.");
        }
        if (ranges.size() > maxSplitsPerRequest) {
            throw new PdfProcessingException("No more than " + maxSplitsPerRequest + " page ranges are allowed per request.");
        }

        File sourceFile = new File(filePath);
        if (!sourceFile.exists() || !sourceFile.isFile()) {
            throw new PdfProcessingException("Source file no longer exists on the server: " + filePath);
        }

        List<SplitResult> results = new ArrayList<>();

        try (PDDocument sourceDoc = Loader.loadPDF(sourceFile)) {
            int totalPages = sourceDoc.getNumberOfPages();

            List<PageRange> validRanges = new ArrayList<>();
            for (PageRange range : ranges) {
                String validationError = validateRange(range, totalPages);
                if (validationError != null) {
                    results.add(SplitResult.failed(
                            range.getFromPage() == null ? 0 : range.getFromPage(),
                            range.getToPage() == null ? 0 : range.getToPage(),
                            validationError));
                } else {
                    validRanges.add(range);
                }
            }

            checkOverlaps(validRanges, results);

            for (PageRange range : ranges) {
                if (!validRanges.contains(range)) {
                    continue; // already recorded as failed above
                }
                try {
                    String outputPath = buildOutputPath(sourceFile, range.getFromPage(), range.getToPage());
                    File outputFile = new File(outputPath);

                    if (method == SplitMethod.SPLITTER) {
                        splitUsingSplitter(sourceFile, range, outputFile);
                    } else {
                        splitUsingImportPage(sourceDoc, range, outputFile);
                    }

                    results.add(SplitResult.ok(range.getFromPage(), range.getToPage(),
                            outputFile.getName(), outputFile.getAbsolutePath()));

                } catch (Exception e) {
                    log.error("Failed to split range {} using {}", range, method, e);
                    results.add(SplitResult.failed(range.getFromPage(), range.getToPage(),
                            "Failed to split this range: " + e.getMessage()));
                }
            }

        } catch (IOException e) {
            throw new PdfProcessingException("Failed to open source PDF: " + e.getMessage(), e);
        }

        return results;
    }

    /**
     * Strategy 1: org.apache.pdfbox.multipdf.Splitter.
     *
     * Opens its own fresh copy of the source document per range so that
     * Splitter's internal state (start/end/splitAtPage) from one range can
     * never leak into another. Splitter's setSplitAtPage(endPage - startPage + 1)
     * makes it emit exactly one output document covering the whole range in a
     * single call to split().
     */
    private void splitUsingSplitter(File sourceFile, PageRange range, File outputFile) throws IOException {
        try (PDDocument doc = Loader.loadPDF(sourceFile)) {
            Splitter splitter = new Splitter();
            splitter.setStartPage(range.getFromPage());
            splitter.setEndPage(range.getToPage());
            splitter.setSplitAtPage(range.getToPage() - range.getFromPage() + 1);

            List<PDDocument> pieces = splitter.split(doc);
            if (pieces.isEmpty()) {
                throw new PdfProcessingException("Splitter produced no output for range " + range);
            }
            if (pieces.size() > 1) {
                log.warn("Splitter produced {} documents for a single range {}; only the first will be kept", pieces.size(), range);
            }

            try (PDDocument result = pieces.get(0)) {
                result.save(outputFile);
            } finally {
                for (int i = 1; i < pieces.size(); i++) {
                    pieces.get(i).close();
                }
            }
        }
    }

    /**
     * Strategy 2: PDDocument.importPage() per page.
     *
     * Reuses the already-open shared source document (safe: PDDocument/PDPage
     * reads are not mutated by importing into a different target document) so
     * repeated ranges from the same split() call don't each re-open the file
     * from disk.
     */
    private void splitUsingImportPage(PDDocument sourceDoc, PageRange range, File outputFile) throws IOException {
        try (PDDocument outputDoc = new PDDocument()) {
            for (int pageNum = range.getFromPage(); pageNum <= range.getToPage(); pageNum++) {
                outputDoc.importPage(sourceDoc.getPage(pageNum - 1));
            }
            outputDoc.save(outputFile);
        }
    }

    private String validateRange(PageRange range, int totalPages) {
        if (range.getFromPage() == null || range.getToPage() == null) {
            return "fromPage and toPage are both required.";
        }
        if (range.getFromPage() < 1 || range.getToPage() < 1) {
            return "Page numbers must be 1 or greater.";
        }
        if (range.getFromPage() > range.getToPage()) {
            return "fromPage (" + range.getFromPage() + ") cannot be greater than toPage (" + range.getToPage() + ").";
        }
        if (range.getToPage() > totalPages) {
            return "toPage (" + range.getToPage() + ") exceeds the document's total pages (" + totalPages + ").";
        }
        return null;
    }

    /**
     * Flags overlapping ranges as failed too (e.g. 1-3 and 2-4 both requested).
     * This is a business-rule check, not a PDFBox limitation — PDFBox is happy
     * to produce overlapping output files, but silently doing so is rarely what
     * an enterprise user actually wants, so we surface it instead of guessing.
     */
    private void checkOverlaps(List<PageRange> validRanges, List<SplitResult> results) {
        List<PageRange> toRemove = new ArrayList<>();
        for (int i = 0; i < validRanges.size(); i++) {
            for (int j = i + 1; j < validRanges.size(); j++) {
                PageRange a = validRanges.get(i);
                PageRange b = validRanges.get(j);
                boolean overlap = a.getFromPage() <= b.getToPage() && b.getFromPage() <= a.getToPage();
                if (overlap) {
                    String msg = "Overlaps with another requested range (" + b.getFromPage() + "-" + b.getToPage() + ").";
                    results.add(SplitResult.failed(a.getFromPage(), a.getToPage(), msg));
                    toRemove.add(a);
                }
            }
        }
        validRanges.removeAll(toRemove);
    }

    private String buildOutputPath(File sourceFile, int fromPage, int toPage) {
        File parentDir = sourceFile.getParentFile();
        String parentPath = (parentDir != null) ? parentDir.getAbsolutePath() : ".";

        String fileName = sourceFile.getName();
        int dotIndex = fileName.lastIndexOf('.');
        String baseName = dotIndex > 0 ? fileName.substring(0, dotIndex) : fileName;
        String extension = dotIndex > 0 ? fileName.substring(dotIndex) : "";

        // Strip the random UUID suffix we appended at upload time so the output
        // file name reflects the original name the user recognizes, not the
        // internal stored name.
        baseName = baseName.replaceFirst("_[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$", "");

        String newFileName = baseName + "_" + fromPage + "_" + toPage + extension;
        return parentPath + File.separator + newFileName;
    }

    private String stripExtension(String fileName) {
        int dotIndex = fileName.lastIndexOf('.');
        return dotIndex > 0 ? fileName.substring(0, dotIndex) : fileName;
    }

    private String sanitizeFileName(String name) {
        return name.replaceAll("[^a-zA-Z0-9-_]", "_");
    }

    public static class StoredFile {
        private final String originalFileName;
        private final String filePath;
        private final int totalPages;

        public StoredFile(String originalFileName, String filePath, int totalPages) {
            this.originalFileName = originalFileName;
            this.filePath = filePath;
            this.totalPages = totalPages;
        }

        public String getOriginalFileName() {
            return originalFileName;
        }

        public String getFilePath() {
            return filePath;
        }

        public int getTotalPages() {
            return totalPages;
        }
    }
}
